HackerSM64_B3313 Build
This is the B3313 style build of HackerSM64.
Enjoy the surreal SM64 experience with non-linear level design, updated textures, and unique gameplay features (including Luigi mode).
